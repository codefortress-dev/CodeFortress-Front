export interface CategoriaAtencion {
  id: string;    // ej: 'comercial', 'tecnico'
  nombre: string; // ej: 'Área Comercial'
}
