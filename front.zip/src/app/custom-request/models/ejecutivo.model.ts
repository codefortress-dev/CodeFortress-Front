export interface Ejecutivo {
  nombre: string;
  categoria: string; // debe coincidir con id de CategoriaAtencion
}
